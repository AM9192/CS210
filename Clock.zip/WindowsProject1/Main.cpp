#include "Clock.h"
#include <conio.h>

void menu()
{
	//display MENU
	cout << "*********************************" << endl;
	cout << "* 1 - Add One Hour \t\t*" << endl;
	cout << "* 2 - Add One Minute \t\t*" << endl;
	cout << "* 3 - Add One Second \t\t*" << endl;
	cout << "* 4 - Exit \t\t\t*" << endl;
	cout << "*********************************" << endl;
}

int main()
{
	//creating 2 clocks - 1 in 12 hour fomrat, 1 in 24 hour format
	Clock clock12(false), clock24(true);
	int choice;
	bool exit = false; //variable to keep track of whether program should exit or not

		//loop used to run code until user exit
		while (!exit)
		{
			cout << endl;
			cout << "**************** ****************" << endl;
			cout << "* " << setw(12);
			clock12.displayTime(cout); //displaying time of 12 hour clock
			cout << " *";
			cout << "* " << setw(12);
			clock24.displayTime(cout); //displaying time of 24 hour clock
			cout << "\t*" << endl;
			cout << "**************** ****************" << endl;
			cout << endl;
			menu();
			cin >> choice; //user choice
			switch(choice)
			{
				case 1:
					clock12.addHours(1);
					clock24.addHours(1);
					break;
				case 2:
					clock12.addMinutes(1);
					clock24.addMinutes(1);
					break;
				case 3:
					clock12.addSeconds(1);
					clock24.addSeconds(1);
					break;
				case 4:
					exit = true;
				default:
					break;
			}
		}
}