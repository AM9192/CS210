#ifndef CLOCK_H_
#define CLOCK_H_

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <iomanip>

using namespace std;
// Clock Class declaration
class Clock
{
private:
	//structure to store time
	struct tm* localTimes;
	//private member variables to store hours, minutes, seconds added to clock
	int d_hours;
	int d_mins;
	int d_secs;
	bool format_24;
public:
	Clock(bool format_24);
	//call all methods
	void addHours(int hours); //Method to add hours
	void addMinutes(int mins); //Method to add seconds
	void resetClock(); //Method to reset clock
	void displayTime(ostream& out); //Method to display time
};

#endif 