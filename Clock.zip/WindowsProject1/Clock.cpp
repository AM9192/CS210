//C++ code
//Header file to call Clock.h file
#include "Clock.h"
//constructor intializes the object with current time
Clock::Clock(bool format_24)
{

	//initialize times
	time_t seconds = time(0);
	localTime = localtime(&seconds);
	d_hours = 0;
	d_secs = 0;
	d_mins = 0;
	//access class
	this->format_24 = format_24;
}
//function to add hours to clock
void Clock::addHours(int hours)
	{
	d_hours += hours;
	}
//functions to add minutes
void Clock::addMinutes(int mins)
{
	d_mins += mins;
}
//function to add seconds
void Clock::addSeconds(int secs)
{
	d_secs += secs;
}
//function to reset clock
{
	d_hours = 0;
	d_secs = 0;
	d_mins = 0;
}
//function to display local time
void Clock::displayTime(ostream& out);
{
	int seconds = 0, minutes = 0, hours = 0;
	seconds = localTime -> tm_sec + d_secs;
	minutes += (seconds / 60);
	seconds = seconds % 60;

	minutes += localTime->tm_min + d_mins;
	hours += minutes / 60;
	minutes = minutes % 60;

	hours = (hours + localTime->tm_hour + d_hours) % 24;

	//output time in specified format
	string timestr = "";
	out << setw(2) << setfill('0') << (format_24 ? hours : (hours % 12)) << ":";
	out << setw(2) << setfill('0') << minutes << " ";
	out << setw(2) << setfill('0') << seconds << " ";
	//if time format is 12-hour, add AM or PM when necessary
	if (!format_24)
	{
		if (hours > 12)
		{
			out << "PM";
		}
		else
		{
			out << "AM";
		}
	}
}